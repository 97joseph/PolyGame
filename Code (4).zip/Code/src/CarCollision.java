
import java.awt.geom.Rectangle2D;


public interface CarCollision {
	
	Rectangle2D.Double getCollisionBox();
	
}
//Defaults