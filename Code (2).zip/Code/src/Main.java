
import javax.swing.JFrame;


public class Main {
    public static void main(String[] args){
        JFrame frame = new WindowGUI();
    frame.setTitle("p7Hanye_W");
    frame.setSize(700, 700);
    frame.setLocation(100, 100);
    frame.setDefaultCloseOperation(3);
    frame.setVisible(true);
  }
}
//